package com.application.pota.ruangan;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Ruangan {
    private  int idRuangan;
    private  String namaRuangan;
}
