package com.application.pota.dosen;
import org.springframework.stereotype.Repository;

@Repository
public interface DosenRepository {
}