package com.application.pota.tugasakhir;

import org.springframework.stereotype.Service;

@Service
public class TugasAkhirService {

    private  TugasAkhirRepository tugasAkhirRepository;
//    public TugasAkhir TAbyIdPengguna(String idPengguna) {
//        return tugasAkhirRepository.getTugasAkhir(idPengguna);
//    }

}
