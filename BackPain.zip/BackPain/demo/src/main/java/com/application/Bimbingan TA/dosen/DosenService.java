package com.application.pota.dosen;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DosenService {

//    public List<String> getTopikBimbingan(String idPengguna) {
//
//    }
}
