package com.application.pota;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PotaApplicationTests {

	@Test
	void contextLoads() {
	}

}
